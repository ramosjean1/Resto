* `Puntsistemes <https://www.puntsistemes.es>`_:

  * Carlos Ramos Hernández

* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza

* `CommitSun <https://www.commitsun.com>`_:

  * Darío Lodeiros

* `Solvos <https://www.solvos.es>`_:

  * David Alonso

* `Sygel <https://www.sygel.es>`_:

  * Manuel Regidor

* `ALBA Software <https://www.albasoft.com>`_:

  * Rafa Morant
