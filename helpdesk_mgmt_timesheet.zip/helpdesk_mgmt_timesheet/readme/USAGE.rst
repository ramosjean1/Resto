#. Go to *Helpdesk* or *Helpdesk > Dashboard* to see the tickets dashboard.
#. In the Kanban view, click in the kanban card of a team to see their tickets and create new ones.
#. If there is not a Default Project you will need select a Project for the Ticket to show the Timesheet Table.
