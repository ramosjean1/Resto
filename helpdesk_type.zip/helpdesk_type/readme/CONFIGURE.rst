* Go to Helpdesk > Configuration > Ticket Types
* Create your list of types
